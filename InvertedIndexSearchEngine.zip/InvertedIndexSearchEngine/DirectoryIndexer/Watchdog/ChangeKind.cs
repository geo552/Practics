﻿namespace DirectoryIndexer
{
    enum ChangeKind
    {
        Existed,
        Created,
        Deleted,
        Updated
    }
}