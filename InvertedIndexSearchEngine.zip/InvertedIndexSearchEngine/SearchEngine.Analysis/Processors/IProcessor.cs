﻿namespace SearchEngine.Analysis
{
    public interface IProcessor
    {
        string ProcessToken(string token);
    }
}