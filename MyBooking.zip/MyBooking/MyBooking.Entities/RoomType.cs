﻿
namespace MyBooking.Entities
{
    public class RoomType
    {
        public int Id { get; set; }
        public string TypeOfRoom { get; set; }
        public int RoomCount { get; set; }
    }
}
