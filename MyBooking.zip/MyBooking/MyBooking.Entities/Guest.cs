﻿
namespace MyBooking.Entities
{
    public class Guest
    {
        public int Id { get; set; }
        public string FirstName {get; set;}
        public string SecondName { get; set; }
    }
}
