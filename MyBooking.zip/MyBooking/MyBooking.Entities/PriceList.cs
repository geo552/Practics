﻿
namespace MyBooking.Entities
{
    public class PriceList
    {
        public string TypeOfRoom { get; set; }
        public decimal Rate { get; set; }
        public int PlacesCount { get; set; }

    }
}
