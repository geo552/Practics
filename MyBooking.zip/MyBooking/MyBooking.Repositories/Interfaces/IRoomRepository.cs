﻿using System;
using System.Collections.Generic;
using MyBooking.Entities;

namespace MyBooking.Repositories.Interfaces
{
    public interface IRoomRepository
    {
        IEnumerable<Room> GetAllRooms();
        Room GetRoomInformation(string roomNumber);
        IEnumerable<Room> GetAvailableRoomsByDate(DateTime date);
    }
}
