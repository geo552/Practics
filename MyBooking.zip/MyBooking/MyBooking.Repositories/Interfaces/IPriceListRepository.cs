﻿
using System.Collections.Generic;

using MyBooking.Entities;

namespace MyBooking.Repositories.Interfaces
{
    public interface IPriceListRepository
    {
        IEnumerable<PriceList> GetPriceList();
    }
}
