﻿
namespace MyBooking.Repositories.Interfaces
{
    public interface IEncryptionProvider
    {
        string EncryptPassword(string password);
    }
}
